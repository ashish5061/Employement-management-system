package EMS;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class TextEmployeeOperations {

    public static void addEmployee(Scanner sc, EmployeeManager manager, String filename) {
        try {
            int id = InputUtils.readInt(sc, "ID: ");
            System.out.print("Name: ");
            String name = sc.nextLine().trim();
            System.out.print("Department: ");
            String dept = sc.nextLine().trim();
            System.out.print("Type (regular/manager/intern): ");
            String type = sc.nextLine().trim().toLowerCase();
            double sal = InputUtils.readDouble(sc, "Base Salary: ");
            int rating = InputUtils.readInt(sc, "Performance Rating (1-5): ");

            Employee emp = switch (type) {
                case "regular" -> new RegularEmployee(id, name, dept, rating, sal);
                case "manager" -> new Manager(id, name, dept, rating, sal);
                case "intern" -> new Intern(id, name, dept, rating, sal);
                default -> null;
            };

            if (emp != null) {
                manager.addEmployee(emp);
                System.out.println("Employee added successfully.");

                if (!filename.isEmpty()) {
                    boolean success = FileHandler.appendToFile(filename, emp);
                    if (success) {
                        System.out.println("Employee also saved to file: " + filename);
                    } else {
                        throw new IOException("Failed to save employee to file: " + filename);
                    }
                }
            } else {
                System.out.println("Invalid employee type.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input! Please try again carefully.");
            sc.nextLine();
        } catch (IOException e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }

    public static void updateEmployee(Scanner sc, EmployeeManager manager, String filename) {
        int id = InputUtils.readInt(sc, "Enter ID of employee to update: ");
        Employee emp = manager.findById(id);
        if (emp != null) {
            boolean updating = true;
            while (updating) {
                System.out.println("\nCurrent Details: " + emp.getDetails());
                System.out.println("1. Name");
                System.out.println("2. Department");
                System.out.println("3. Base Salary");
                System.out.println("4. Performance Rating");
                System.out.println("5. Done updating");
                int option = InputUtils.readInt(sc, "Choose an option: ");

                switch (option) {
                    case 1 -> {
                        System.out.print("Enter new name: ");
                        emp.name = sc.nextLine().trim();
                    }
                    case 2 -> {
                        System.out.print("Enter new department: ");
                        emp.department = sc.nextLine().trim();
                    }
                    case 3 -> emp.baseSalary = InputUtils.readDouble(sc, "Enter new base salary: ");
                    case 4 -> emp.performanceRating = InputUtils.readInt(sc, "Enter new performance rating: ");
                    case 5 -> updating = false;
                    default -> System.out.println("Invalid option.");
                }
            }
            System.out.println("Employee updated successfully.");
            if (!filename.isEmpty()) {
                FileHandler.saveToFile(filename, manager.employees);
                System.out.println("Changes saved to file: " + filename);
            }
        } else {
            System.out.println("Employee not found.");
        }
    }

    public static void deleteEmployee(Scanner sc, EmployeeManager manager, String filename) {
        int id = InputUtils.readInt(sc, "Enter ID to delete: ");
        if (manager.findById(id) != null) {
            manager.deleteEmployee(id);
            System.out.println("Employee deleted.");
            if (!filename.isEmpty()) {
                FileHandler.saveToFile(filename, manager.employees);
                System.out.println("Changes saved to file: " + filename);
            }
        } else {
            System.out.println("Employee with ID " + id + " not found.");
        }
    }

    public static void queryEmployee(Scanner sc, EmployeeManager manager) {
        System.out.println("1. Query by ID");
        System.out.println("2. Query by name");
        System.out.println("3. Query by rating");
        int q = InputUtils.readInt(sc, "Choose query option: ");

        switch (q) {
            case 1 -> {
                int id = InputUtils.readInt(sc, "Enter ID: ");
                Employee e = manager.findById(id);
                if (e != null) {
                    System.out.println(e.getDetails());
                } else {
                    System.out.println("Employee not found.");
                }
            }
            case 2 -> {
                System.out.print("Enter name: ");
                String name = sc.nextLine().trim();
                manager.queryByName(name);
            }
            case 3 -> {
                int rating = InputUtils.readInt(sc, "Enter rating: ");
                manager.queryByRating(rating);
            }
            default -> System.out.println("Invalid query option.");
        }
    }
}
