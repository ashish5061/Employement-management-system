package EMS;

public class TextMenu {

    public static void printMainMenu() {
        System.out.println("\n===== Employee Management System =====");
        System.out.println("1. Add new employee");
        System.out.println("2. Update employee");
        System.out.println("3. Delete employee");
        System.out.println("4. Query employee details");
        System.out.println("5. Save to file");
        System.out.println("6. Manage performance and salary");
        System.out.println("7. Exit");
    }
}
