package EMS;

import javax.swing.*;
import java.util.Scanner;

public class EmployeeManagementSystem {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        EmployeeManager manager = new EmployeeManager();

        String filename = "employee_data.csv";
        FileHandler.loadFromFile(filename, manager);  // Load only once
        System.out.println("Employee records loaded from " + filename);

        while (true) {
            System.out.println("\nChoose interface mode:");
            System.out.println("1. Text-Based Interface");
            System.out.println("2. Graphical User Interface (GUI)");
            System.out.println("3. Exit");

            int modeChoice = InputUtils.readInt(sc, "Enter choice: ");

            switch (modeChoice) {
                case 1 -> TextInterface.run(sc, manager, filename);  // Text UI
                case 2 -> {
                    sc.close();  // Close console input
                    SwingUtilities.invokeLater(() -> {
                        EMSGui gui = new EMSGui(manager, filename);  // GUI reuses data
                        gui.setVisible(true);
                    });
                    return;
                }
                case 3 -> {
                    System.out.println("Exiting program. Goodbye!");
                    sc.close();
                    return;
                }
                default -> System.out.println("Invalid choice! Please try again.");
            }
        }
    }
}
