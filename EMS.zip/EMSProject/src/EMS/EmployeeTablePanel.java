package EMS;

import javax.swing.*;
import java.awt.*;

public class EmployeeTablePanel extends JPanel {

    private final JTable employeeTable;
    private final EmployeeTableModel tableModel;
    private final EmployeeManager manager;

    public EmployeeTablePanel(EmployeeManager manager) {
        this.manager = manager;
        this.setLayout(new BorderLayout());
        this.tableModel = new EmployeeTableModel(manager);
        this.employeeTable = new JTable(tableModel);
        this.employeeTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(employeeTable);
        this.add(scrollPane, BorderLayout.CENTER);
    }

    // ✅ This method must be public
    public void refreshTable() {
        tableModel.fireTableDataChanged();
    }

    public JTable getTable() {
        return employeeTable;
    }

    public Employee getSelectedEmployee() {
        int viewRow = employeeTable.getSelectedRow();
        if (viewRow >= 0) {
            int modelRow = employeeTable.convertRowIndexToModel(viewRow);  // ✅ Correct row for sorting
            return manager.employees.get(modelRow);
        }
        return null;
    }

    
    public EmployeeManager getManager() {
        return this.manager;
    }
}
