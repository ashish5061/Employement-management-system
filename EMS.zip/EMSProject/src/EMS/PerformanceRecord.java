package EMS;

import java.util.*;

public class PerformanceRecord {
    public List<String> warnings = new ArrayList<>();
    public List<String> appreciations = new ArrayList<>();

    public void addWarning(String reason) {
        warnings.add(reason);
    }

    public void addAppreciation(String note) {
        appreciations.add(note);
    }
}
