package EMS;

import javax.swing.*;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.util.Comparator;

public class EmployeeEditDialog extends JDialog {

    public EmployeeEditDialog(JFrame parent, Employee emp, String filename, EmployeeTablePanel tablePanel) {
        super(parent, "Edit Employee - ID " + emp.getId(), true);
        setSize(460, 350);
        setLocationRelativeTo(parent);
        setResizable(false);
        setLayout(new BorderLayout(10, 10));

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(15, 25, 10, 25));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;

        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField(emp.getName(), 20);

        JLabel deptLabel = new JLabel("Department:");
        JTextField deptField = new JTextField(emp.getDepartment(), 20);

        JLabel typeLabel = new JLabel("Type:");
        JComboBox<String> typeBox = new JComboBox<>(new String[]{"Regular", "Manager", "Intern"});
        typeBox.setPreferredSize(new Dimension(200, 25)); 


        JLabel salaryLabel = new JLabel("Base Salary:");
        JTextField salaryField = new JTextField(String.valueOf(emp.baseSalary), 20);

        JLabel ratingLabel = new JLabel("Performance Rating:");
        JTextField ratingField = new JTextField(String.valueOf(emp.getPerformanceRating()), 20);

        gbc.gridx = 0; gbc.gridy = 0; formPanel.add(nameLabel, gbc);
        gbc.gridx = 1; formPanel.add(nameField, gbc);
        gbc.gridx = 0; gbc.gridy = 1; formPanel.add(deptLabel, gbc);
        gbc.gridx = 1; formPanel.add(deptField, gbc);
        gbc.gridx = 0; gbc.gridy = 2; formPanel.add(typeLabel, gbc);
        gbc.gridx = 1; formPanel.add(typeBox, gbc);
        gbc.gridx = 0; gbc.gridy = 3; formPanel.add(salaryLabel, gbc);
        gbc.gridx = 1; formPanel.add(salaryField, gbc);
        gbc.gridx = 0; gbc.gridy = 4; formPanel.add(ratingLabel, gbc);
        gbc.gridx = 1; formPanel.add(ratingField, gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnSave = new JButton("Save");
        JButton btnCancel = new JButton("Cancel");
        buttonPanel.add(btnCancel);
        buttonPanel.add(btnSave);

        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        btnSave.addActionListener(e -> {
            try {
                String name = nameField.getText().trim();
                String dept = deptField.getText().trim();
                String type = (String) typeBox.getSelectedItem();
                double salary = Double.parseDouble(salaryField.getText().trim());
                int rating = Integer.parseInt(ratingField.getText().trim());

                Employee updatedEmp = switch (type.toLowerCase()) {
                    case "manager" -> new Manager(emp.getId(), name, dept, rating, salary);
                    case "intern" -> new Intern(emp.getId(), name, dept, rating, salary);
                    default -> new RegularEmployee(emp.getId(), name, dept, rating, salary);
                };

                EmployeeManager manager = tablePanel.getManager();
                manager.deleteEmployee(emp.getId());
                manager.addEmployee(updatedEmp);
                manager.employees.sort(Comparator.comparingInt(Employee::getId));
                FileHandler.saveToFile(filename, manager.employees);
                tablePanel.refreshTable();
                dispose();

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid input: " + ex.getMessage());
            }
        });

        btnCancel.addActionListener(e -> dispose());

        JTable table = tablePanel.getTable();
        TableRowSorter<TableModel> sorter = new TableRowSorter<>(table.getModel());
        table.setRowSorter(sorter);
        sorter.setComparator(4, Comparator.comparingDouble(o -> Double.parseDouble(o.toString())));

    }
}
