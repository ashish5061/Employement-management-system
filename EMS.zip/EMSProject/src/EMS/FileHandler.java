package EMS;

import java.io.*;
import java.util.*;

public class FileHandler {

    // ✅ Load employees from CSV file into the manager
    public static void loadFromFile(String filename, EmployeeManager manager) {
        File file = new File(filename);

        if (!file.exists()) {
            System.out.println("File does not exist at: " + file.getAbsolutePath());
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            manager.employees.clear();

            // Skip header
            br.readLine();

            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length < 6) continue;  // ✅ Skip malformed rows

                int id = Integer.parseInt(data[0].trim());
                String name = data[1].trim();
                String dept = data[2].trim();
                String type = data[3].trim().toLowerCase();
                double salary = Double.parseDouble(data[4].trim());
                int rating = Integer.parseInt(data[5].trim());

                Employee emp = switch (type) {
                    case "regular" -> new RegularEmployee(id, name, dept, rating, salary);
                    case "manager" -> new Manager(id, name, dept, rating, salary);
                    case "intern" -> new Intern(id, name, dept, rating, salary);
                    default -> null;
                };

                if (emp != null) manager.addEmployee(emp);
            }

            System.out.println("Loaded " + manager.employees.size() + " employees from file.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error loading file: " + e.getMessage());
        }
    }

    // ✅ Save the entire employee list to file (overwrite)
    public static void saveToFile(String filename, List<Employee> employees) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(filename))) {
            pw.println("ID,Name,Department,Type,BaseSalary,PerformanceRating"); // Header
            for (Employee emp : employees) {
                pw.println(toCSV(emp));
            }
            System.out.println("Saved " + employees.size() + " employees to file.");
        } catch (IOException e) {
            System.err.println("Error saving to file: " + e.getMessage());
        }
    }

    // ✅ Append a single employee to the file
    public static boolean appendToFile(String filename, Employee emp) {
        try (FileWriter writer = new FileWriter(filename, true)) { // 'true' enables append mode
            writer.write(toCSV(emp) + "\n");
            return true;
        } catch (IOException e) {
            System.out.println("Error appending to file: " + e.getMessage());
            return false;
        }
    }

    // ✅ Convert employee data to proper CSV line
    private static String toCSV(Employee emp) {
        return String.format("%d,%s,%s,%s,%.2f,%d",
                emp.getId(),
                emp.getName(),
                emp.getDepartment(),
                emp.getClass().getSimpleName(),
                emp.baseSalary,
                emp.getPerformanceRating());
    }
}
