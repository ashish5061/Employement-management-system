package EMS;

public class Manager extends Employee {
    public Manager(int id, String name, String department, int performanceRating, double baseSalary) {
        super(id, name, department, performanceRating, baseSalary);
    }

    @Override
    public double calculateSalary() {
        return baseSalary + (performanceRating * 150) + 500;
    }
}
