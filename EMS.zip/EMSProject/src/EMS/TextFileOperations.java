// TextFileOperations.java
package EMS;

import java.util.Scanner;

public class TextFileOperations {

    public static String saveToFile(Scanner sc, EmployeeManager manager) {
        System.out.print("Enter file name to save: ");
        String filename = sc.nextLine().trim();
        if (!filename.isEmpty()) {
            FileHandler.saveToFile(filename, manager.employees);
            System.out.println("Employees saved to file: " + filename);
        } else {
            System.out.println("Invalid filename. Please try again.");
        }
        return filename;
    }
}