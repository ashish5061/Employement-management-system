package EMS;

public class RegularEmployee extends Employee {
    public RegularEmployee(int id, String name, String department, int performanceRating, double baseSalary) {
        super(id, name, department, performanceRating, baseSalary);
    }

    @Override
    public double calculateSalary() {
        return baseSalary + (performanceRating * 100);
    }
}
