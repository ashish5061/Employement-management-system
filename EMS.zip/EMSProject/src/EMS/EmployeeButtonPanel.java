package EMS;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.awt.event.ActionListener;

public class EmployeeButtonPanel extends JPanel {

    private final JTextField searchField = new JTextField(15);

    public EmployeeButtonPanel(EmployeeManager manager, String filename, EmployeeTablePanel tablePanel) {
        setLayout(new FlowLayout(FlowLayout.LEFT));

        add(createButton("Add Employee", e -> new EmployeeAddDialog(null, manager, filename, tablePanel)));

        add(createButton("Delete Selected", e -> {
            Employee emp = tablePanel.getSelectedEmployee();
            if (emp != null) {
                int confirm = JOptionPane.showConfirmDialog(this, "Delete employee: " + emp.getName() + "?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    manager.deleteEmployee(emp.getId());
                    FileHandler.saveToFile(filename, manager.employees);
                    tablePanel.refreshTable();
                }
            } else {
                JOptionPane.showMessageDialog(this, "No employee selected.");
            }
        }));

        add(createButton("Refresh", e -> tablePanel.refreshTable()));

        add(createButton("Edit Selected", e -> {
            System.out.println("Edit button clicked");
            Employee selected = tablePanel.getSelectedEmployee();
            if (selected != null) {

                // ✅ Safer way to show dialog: always use a window as parent
                SwingUtilities.invokeLater(() -> {
                    JDialog dialog = new EmployeeEditDialog(
                        SwingUtilities.getWindowAncestor(this) instanceof JFrame
                            ? (JFrame) SwingUtilities.getWindowAncestor(this)
                            : new JFrame(),
                        selected,
                        filename,
                        tablePanel
                    );
                    dialog.setVisible(true);  // ✅ Ensure it’s shown!
                });

            } else {
                JOptionPane.showMessageDialog(this, "Please select an employee to edit.");
            }
        }));


        add(new JLabel("Name:"));
        add(searchField);

        add(createButton("Search", e -> {
            String name = searchField.getText().trim();
            if (name.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Enter a name.");
                return;
            }

            List<Employee> results = manager.employees.stream()
                    .filter(emp -> emp.getName().equalsIgnoreCase(name))
                    .toList();

            if (results.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No employee found.");
            } else {
                new EmployeeSearchDialog(null, results);
            }
        }));
    }

    private JButton createButton(String text, ActionListener action) {
        JButton btn = new JButton(text);
        btn.addActionListener(action);
        return btn;
    }
}
