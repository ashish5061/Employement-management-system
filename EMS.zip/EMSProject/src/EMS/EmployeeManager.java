package EMS;

import java.util.*;

public class EmployeeManager {
    public List<Employee> employees = new ArrayList<>();

    public void addEmployee(Employee emp) {
        employees.add(emp);
        System.out.println("Employee added!");
    }

    public Employee findById(int id) {
        return employees.stream().filter(e -> e.getId() == id).findFirst().orElse(null);
    }

    public void deleteEmployee(int id) {
        Employee emp = findById(id);
        if (emp != null) {
            employees.remove(emp);
            System.out.println("Employee deleted.");
        } else {
            System.out.println("Employee not found.");
        }
    }

    public void queryByName(String name) {
        for (Employee e : employees) {
            if (e.getName().equalsIgnoreCase(name)) {
                System.out.println(e.getDetails());
            }
        }
    }

    public void queryByRating(int rating) {
        for (Employee e : employees) {
            if (e.getPerformanceRating() == rating) {
                System.out.println(e.getDetails());
            }
        }
    }

    public void listAllEmployees() {
        for (Employee e : employees) {
            System.out.println(e.getDetails());
        }
    }
}
