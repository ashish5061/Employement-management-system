// TextInterface.java
package EMS;

import java.util.*;

public class TextInterface {

    public static void run(Scanner sc, EmployeeManager manager, String filename) {
        while (true) {
            printMainMenu();
            int choice = InputUtils.readInt(sc, "Choose an option: ");

            switch (choice) {
                case 1 -> TextEmployeeOperations.addEmployee(sc, manager, filename);
                case 2 -> TextEmployeeOperations.updateEmployee(sc, manager, filename);
                case 3 -> TextEmployeeOperations.deleteEmployee(sc, manager, filename);
                case 4 -> TextEmployeeOperations.queryEmployee(sc, manager);
                case 5 -> filename = TextFileOperations.saveToFile(sc, manager);
                case 6 -> TextPerformanceManager.managePerformance(sc, manager);
                case 7 -> sortEmployees(sc, manager);
                case 8 -> searchEmployee(sc, manager);
                case 9 -> {
                    System.out.println("Returning to interface selection...");
                    return;
                }
                default -> System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    private static void printMainMenu() {
        System.out.println("\n===== Employee Management System =====");
        System.out.println("1. Add new employee");
        System.out.println("2. Update employee");
        System.out.println("3. Delete employee");
        System.out.println("4. Query employee details");
        System.out.println("5. Save to file");
        System.out.println("6. Manage performance and salary");
        System.out.println("7. Sort employees");
        System.out.println("8. Search employees");
        System.out.println("9. Exit");
    }

    private static void sortEmployees(Scanner sc, EmployeeManager manager) {
        System.out.println("\n-- Sorting Options --");
        System.out.println("1. Bubble Sort by Name (A-Z)");
        System.out.println("2. Quick Sort by Salary (Low to High)");

        int choice = InputUtils.readInt(sc, "Choose sort option: ");

        switch (choice) {
            case 1 -> bubbleSortByName(manager.employees);
            case 2 -> quickSortBySalary(manager.employees, 0, manager.employees.size() - 1);
            default -> {
                System.out.println("Invalid sort option.");
                return;
            }
        }

        System.out.println("\n--- Sorted Employees ---");
        for (Employee emp : manager.employees) {
            System.out.println(emp.getDetails());
        }
    }

    private static void bubbleSortByName(List<Employee> list) {
        int n = list.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (list.get(j).getName().compareToIgnoreCase(list.get(j + 1).getName()) > 0) {
                    Collections.swap(list, j, j + 1);
                }
            }
        }
    }

    private static void quickSortBySalary(List<Employee> list, int low, int high) {
        if (low < high) {
            int pi = partition(list, low, high);
            quickSortBySalary(list, low, pi - 1);
            quickSortBySalary(list, pi + 1, high);
        }
    }

    private static int partition(List<Employee> list, int low, int high) {
        double pivot = list.get(high).baseSalary;
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (list.get(j).baseSalary <= pivot) {
                i++;
                Collections.swap(list, i, j);
            }
        }
        Collections.swap(list, i + 1, high);
        return i + 1;
    }

    private static void searchEmployee(Scanner sc, EmployeeManager manager) {
        System.out.println("\n-- Search Options --");
        System.out.println("1. Linear Search by Name");
        System.out.println("2. Binary Search by ID (ensure list is sorted by ID first)");

        int choice = InputUtils.readInt(sc, "Choose search option: ");

        switch (choice) {
            case 1 -> {
                System.out.print("Enter name to search: ");
                String name = sc.nextLine().trim();
                for (Employee emp : manager.employees) {
                    if (emp.getName().equalsIgnoreCase(name)) {
                        System.out.println("Found: " + emp.getDetails());
                        return;
                    }
                }
                System.out.println("Employee not found.");
            }
            case 2 -> {
                manager.employees.sort(Comparator.comparingInt(Employee::getId));
                int id = InputUtils.readInt(sc, "Enter ID to search: ");
                int index = binarySearchById(manager.employees, id);
                if (index >= 0) {
                    System.out.println("Found: " + manager.employees.get(index).getDetails());
                } else {
                    System.out.println("Employee not found.");
                }
            }
            default -> System.out.println("Invalid search option.");
        }
    }

    private static int binarySearchById(List<Employee> list, int id) {
        int low = 0, high = list.size() - 1;
        while (low <= high) {
            int mid = (low + high) / 2;
            if (list.get(mid).getId() == id) return mid;
            if (list.get(mid).getId() < id) low = mid + 1;
            else high = mid - 1;
        }
        return -1;
    }
}
